<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Payroll extends MY_Controller {
    function __construct() {
        parent::__construct();
        $this->load->model('Commonmodel', 'Common');
        $this->load->model('Payrollmodel');
        $this->data['view'] = $this->data['controller'] . '/' . $this->data['method'];
        $this->clear_cache();
        $this->check_login(0);
    }

    /* ------------------- END BLOCK ------------------- */

    /**
     * 
     */
    public function index() {
         header('Location:' . site_url('payroll/all'));
        exit();
    }

    public function all() {
        // echo $this->_random_password(32);
        $headList = $this->Payrollmodel->fetchSalaryHead();
        // print_r($headList);
        $this->load->view('common/header', $this->data);
        $this->load->view('payroll/parentlists', array(
            "headList" => $headList,
        ) );
        $this->load->view('common/footer', $this->data);
    }

    public function my_salary() {
        // echo $this->_random_password(32);
        $emp_id = $this->session->userdata($this->data['sess_code'] . 'user_id');
        $mySalary = $this->Payrollmodel->fetchMySalary($emp_id);
        $this->load->view('common/header', $this->data);
        $this->load->view('payroll/individuallist', array(
            "mySalary" => $mySalary));
        $this->load->view('common/footer', $this->data);
    }

    public function single_slip($slip_id) {
        // echo $this->_random_password(32);
       
        $salarydetails = $this->Payrollmodel->fetchEmployeeSalaryDetails($slip_id);
        $empdetails = $this->Payrollmodel->fetchEmployeeDetails($salarydetails[0]['emp_id']);

        // print_r($empdetails[0]);
        $this->load->view('common/header', $this->data);
        $this->load->view('payroll/single', array(
            "salarydetails" => $salarydetails[0],
            "empdetails"   => $empdetails[0],
        ));
        $this->load->view('common/footer', $this->data);
    }

    public function generate_payslip_ajax(){
        if($this->Payrollmodel->checkPayslipExistInHead(date('M'), date('Y'))){
            echo 0;
        }else{
            $allEmployee = $this->Payrollmodel->getAllEmployeeForPayslip();
            $headdataarray = array(
                "month" =>   date('M'),
                "date"    => date('d'),
                "year"    => date('Y'),

            );
            $head_id = $this->Payrollmodel->insertMonthlyPaysliphead($headdataarray);
     
            $payslipcount = 1;
            foreach($allEmployee as $employee){

                $dataArray = array(
                    "emp_id"  => $employee['id'],
                    "month"   => date('M'),
                    "date"    => date('d'),
                    "year"    => date('Y'),
                    "basics"    => $employee['basics'],
                    "da_type"    => $employee['da_type'],
                    "head_id"   =>  $head_id,
                );
                //insert to salary_heads($dataArray)
                $this->Payrollmodel->insertMonthlyPayslip($dataArray);
                $payslipcount++;
            }
            $headDataUpdate = array(
                "no_of_payslip" =>  $payslipcount -1 
            );
            $this->Payrollmodel->updateMonthlyPaysliphead($headDataUpdate,$head_id);
            echo 1;
        }

    }

    public function da() {
       
        $dadetails = $this->Payrollmodel->daDetails();
        $this->load->view('common/header', $this->data);
        $this->load->view('payroll/da', array(
            "dadetails" => $dadetails
        ));
        $this->load->view('common/footer', $this->data);
    }

    public function insertdadetails(){
        $da_type = $this->input->post('da_type');
        $percentage = $this->input->post('percentage');
        $effect_date = $this->input->post('effect_date');
        $end_date = $this->input->post('end_date');

        $data=array(
            'type'   =>  $da_type,
            'percentage'   =>  $percentage,
            'effective_date'   =>  $effect_date,
            'end_date'   =>  $end_date

        );
        if($this->Payrollmodel->insertDadetails($data)){
          return redirect(site_url('payroll/da'));   
        }
    }

    public function savedadetails(){
        $da_id = $this->input->post('da_id');  
        $da_type = $this->input->post('da_type');
        $percentage = $this->input->post('percentage');
        $effect_date = $this->input->post('effect_date');
        $end_date = $this->input->post('end_date');

        $data=array(
            'type'   =>  $da_type,
            'percentage'   =>  $percentage,
            'effective_date'   =>  $effect_date,
            'end_date'   =>  $end_date
        );

        if($this->Payrollmodel->saveDadetails($data, $da_id)){
          return redirect(site_url('payroll/da'));   
        }
    }


    public function hra() {
       
        $hradetails = $this->Payrollmodel->hraDetails();
        $this->load->view('common/header', $this->data);
        $this->load->view('payroll/hra', array(
            "hradetails" => $hradetails
        ));
        $this->load->view('common/footer', $this->data);
    }

    public function inserthradetails(){
        $location = $this->input->post('location');
        $city_class = $this->input->post('city_class');
        $rate = $this->input->post('rate');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');

        $data=array(
            'location'     =>  $location,
            'city_class'   =>  $city_class,
            'rate'         =>  $rate,
            'start_date'   =>  $start_date,
            'end_date'     =>  $end_date
        );
        if($this->Payrollmodel->inserthradetails($data)){
          return redirect(site_url('payroll/hra'));   
        }
    }

    public function savehradetails(){
        $hra_id = $this->input->post('hra_id');  
        $city_class = $this->input->post('city_class');
        $rate = $this->input->post('rate');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');

        $data=array(
            'city_class'   =>  $city_class,
            'rate'         =>  $rate,
            'start_date'   =>  $start_date,
            'end_date'     =>  $end_date
        );

        if($this->Payrollmodel->saveHraDetails($data, $hra_id)){
          return redirect(site_url('payroll/hra'));   
        }
    }


    
}
